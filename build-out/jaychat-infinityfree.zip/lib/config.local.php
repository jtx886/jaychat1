<?php
// 临时测试配置（部署前会删除）
return array(
    'DB_DRIVER' => 'sqlite',
    'DB_PATH' => dirname(__DIR__) . '/data/test.db',
    'JWT_SECRET' => 'local-test-secret',
    'DEV_MODE' => true,
    'ALLOW_DEV_CODE' => true,
    'UPLOAD_MAX_BYTES' => 10 * 1024 * 1024,
);
