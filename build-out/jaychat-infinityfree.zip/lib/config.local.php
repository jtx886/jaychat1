<?php
// 本地自测临时配置（测试完成后删除，不随部署包发布）
return array(
    'DB_DRIVER' => 'sqlite',
    'DB_PATH' => '/tmp/jc/jaychat.db',
    'JWT_SECRET' => 'dev',
    'DEV_MODE' => true,
    'ALLOW_DEV_CODE' => true,
);
